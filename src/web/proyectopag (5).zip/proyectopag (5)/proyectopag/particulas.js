// ===== MENU TOGGLE =====
const menuToggle = document.getElementById('menuToggle');
const navMenu = document.getElementById('navMenu');

if (menuToggle && navMenu) {
    menuToggle.addEventListener('click', () => {
        navMenu.classList.toggle('active');

        const spans = menuToggle.querySelectorAll('span');
        if (navMenu.classList.contains('active')) {
            spans[0].style.transform = 'rotate(45deg) translate(6px, 6px)';
            spans[1].style.opacity = '0';
            spans[2].style.transform = 'rotate(-45deg) translate(8px, -8px)';
        } else {
            spans[0].style.transform = 'none';
            spans[1].style.opacity = '1';
            spans[2].style.transform = 'none';
        }
    });

    const navLinks = navMenu.querySelectorAll('a');
    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            if (window.innerWidth <= 768) {
                navMenu.classList.remove('active');
                const spans = menuToggle.querySelectorAll('span');
                spans[0].style.transform = 'none';
                spans[1].style.opacity = '1';
                spans[2].style.transform = 'none';
            }
        });
    });
}

// ===== SCROLL SUAVE =====
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// ===== EFECTO PARALLAX AVANZADO =====
window.addEventListener('scroll', () => {
    const scrolled = window.pageYOffset;

    // Parallax en hero
    const hero = document.querySelector('.hero-content');
    const floatingIcons = document.querySelectorAll('.floating-icon');

    if (hero) {
        hero.style.transform = `translateY(${scrolled * 0.5}px)`;
        hero.style.opacity = 1 - (scrolled * 0.0015);
    }

    floatingIcons.forEach((icon, index) => {
        const speed = 0.2 + (index * 0.1);
        const rotation = scrolled * 0.05 * (index % 2 === 0 ? 1 : -1);
        icon.style.transform = `translateY(${scrolled * speed}px) rotate(${rotation}deg) scale(${1 + scrolled * 0.0001})`;
    });

    // Parallax en formas de fondo
    const shapes = document.querySelectorAll('.shape');
    shapes.forEach((shape, index) => {
        const speed = 0.1 + (index * 0.05);
        const rotation = scrolled * 0.02 * (index % 2 === 0 ? 1 : -1);
        shape.style.transform = `translate(${scrolled * speed}px, ${scrolled * speed * 0.5}px) rotate(${rotation}deg)`;
    });
});

// ===== ANIMACIÓN DE APARICIÓN CON INTERSECTION OBSERVER =====
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.animation = 'fadeIn 1s ease-out forwards';
            entry.target.style.opacity = '1';
            observer.unobserve(entry.target);
        }
    });
}, observerOptions);

// Observar elementos
document.querySelectorAll('.intro-card, .feature-item, .value-card, .member-card').forEach(el => {
    el.style.opacity = '0';
    observer.observe(el);
});

// ===== EFECTO 3D EN TARJETAS =====
const cards = document.querySelectorAll('.intro-card, .feature-item, .member-card');
cards.forEach(card => {
    card.addEventListener('mousemove', function(e) {
        if (window.innerWidth > 768) {
            const rect = this.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;

            const centerX = rect.width / 2;
            const centerY = rect.height / 2;

            const rotateX = (y - centerY) / 15;
            const rotateY = (centerX - x) / 15;

            this.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-10px) scale(1.02)`;
        }
    });

    card.addEventListener('mouseleave', function() {
        this.style.transform = 'perspective(1000px) rotateX(0) rotateY(0) translateY(0) scale(1)';
    });
});

// ===== CONTADOR ANIMADO =====
function animateCounter(element, target, duration) {
    let current = 0;
    const increment = target / (duration / 16);
    const suffix = element.dataset.suffix || '';

    const updateCounter = () => {
        current += increment;
        if (current < target) {
            element.textContent = Math.floor(current) + suffix;
            requestAnimationFrame(updateCounter);
        } else {
            element.textContent = target + suffix;
        }
    };

    updateCounter();
}

// Activar contadores cuando sean visibles
const statNumbers = document.querySelectorAll('.stat-number');
const statObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            const target = parseInt(entry.target.dataset.target);
            animateCounter(entry.target, target, 2000);
            statObserver.unobserve(entry.target);
        }
    });
}, { threshold: 0.5 });

statNumbers.forEach(num => {
    num.dataset.suffix = '';
    statObserver.observe(num);
});

// ===== PARTÍCULAS FLOTANTES AVANZADAS =====
function createParticle() {
    const container = document.getElementById('particlesContainer');
    if (!container) return;

    const particle = document.createElement('div');
    const size = Math.random() * 6 + 2;
    const startX = Math.random() * window.innerWidth;
    const colors = ['#2ECC71', '#27AE60', '#F39C12', '#667eea', '#f093fb'];
    const color = colors[Math.floor(Math.random() * colors.length)];

    particle.style.position = 'absolute';
    particle.style.width = size + 'px';
    particle.style.height = size + 'px';
    particle.style.background = color;
    particle.style.borderRadius = '50%';
    particle.style.pointerEvents = 'none';
    particle.style.left = startX + 'px';
    particle.style.top = '-10px';
    particle.style.boxShadow = `0 0 ${size * 2}px ${color}`;
    particle.style.opacity = '0.6';

    container.appendChild(particle);

    const duration = 4000 + Math.random() * 3000;
    const drift = (Math.random() - 0.5) * 100;
    const rotation = Math.random() * 360;
    const start = Date.now();

    function animate() {
        const elapsed = Date.now() - start;
        const progress = elapsed / duration;

        if (progress < 1) {
            const y = progress * (window.innerHeight + 20);
            const x = startX + (drift * progress);
            const rot = rotation * progress;
            const scale = 1 + (Math.sin(progress * Math.PI) * 0.5);

            particle.style.top = y + 'px';
            particle.style.left = x + 'px';
            particle.style.transform = `rotate(${rot}deg) scale(${scale})`;
            particle.style.opacity = 0.6 * (1 - progress);

            requestAnimationFrame(animate);
        } else {
            particle.remove();
        }
    }

    animate();
}

// Crear partículas periódicamente
setInterval(createParticle, 400);
for (let i = 0; i < 10; i++) {
    setTimeout(createParticle, i * 200);
}

// ===== CURSOR PERSONALIZADO (OPCIONAL) =====
let cursorDot = null;
let cursorOutline = null;

function createCustomCursor() {
    if (window.innerWidth > 768) {
        cursorDot = document.createElement('div');
        cursorDot.style.cssText = `
            position: fixed;
            width: 8px;
            height: 8px;
            background: #2ECC71;
            border-radius: 50%;
            pointer-events: none;
            z-index: 10000;
            transition: transform 0.15s ease;
            mix-blend-mode: difference;
        `;

        cursorOutline = document.createElement('div');
        cursorOutline.style.cssText = `
            position: fixed;
            width: 30px;
            height: 30px;
            border: 2px solid rgba(46, 204, 113, 0.5);
            border-radius: 50%;
            pointer-events: none;
            z-index: 10000;
            transition: all 0.15s ease;
            mix-blend-mode: difference;
        `;

        document.body.appendChild(cursorDot);
        document.body.appendChild(cursorOutline);

        document.addEventListener('mousemove', (e) => {
            cursorDot.style.left = e.clientX - 4 + 'px';
            cursorDot.style.top = e.clientY - 4 + 'px';

            cursorOutline.style.left = e.clientX - 15 + 'px';
            cursorOutline.style.top = e.clientY - 15 + 'px';
        });

        // Efecto al hacer hover en elementos interactivos
        const interactiveElements = document.querySelectorAll('a, button, .intro-card, .feature-item, .member-card');
        interactiveElements.forEach(el => {
            el.addEventListener('mouseenter', () => {
                if (cursorDot && cursorOutline) {
                    cursorDot.style.transform = 'scale(1.5)';
                    cursorOutline.style.width = '50px';
                    cursorOutline.style.height = '50px';
                    cursorOutline.style.borderColor = 'rgba(46, 204, 113, 0.8)';
                }
            });

            el.addEventListener('mouseleave', () => {
                if (cursorDot && cursorOutline) {
                    cursorDot.style.transform = 'scale(1)';
                    cursorOutline.style.width = '30px';
                    cursorOutline.style.height = '30px';
                    cursorOutline.style.borderColor = 'rgba(46, 204, 113, 0.5)';
                }
            });
        });
    }
}

createCustomCursor();

// ===== CAMBIO DE HEADER AL HACER SCROLL =====
const header = document.querySelector('header');
let lastScroll = 0;

window.addEventListener('scroll', () => {
    const currentScroll = window.pageYOffset;

    if (currentScroll > 100) {
        header.style.padding = '0.5rem 0';
        header.style.boxShadow = '0 10px 40px rgba(0, 0, 0, 0.4)';
        header.style.background = 'rgba(26, 26, 46, 0.95)';
    } else {
        header.style.padding = '1rem 0';
        header.style.boxShadow = '0 8px 32px rgba(0, 0, 0, 0.3)';
        header.style.background = 'rgba(26, 26, 46, 0.8)';
    }

    // Ocultar header al hacer scroll hacia abajo, mostrar al subir
    if (currentScroll > lastScroll && currentScroll > 500) {
        header.style.transform = 'translateY(-100%)';
    } else {
        header.style.transform = 'translateY(0)';
    }

    lastScroll = currentScroll;
});

// ===== EFECTO TYPEWRITER EN TÍTULOS =====
function typeWriter(element, text, speed = 100) {
    let i = 0;
    element.textContent = '';

    function type() {
        if (i < text.length) {
            element.textContent += text.charAt(i);
            i++;
            setTimeout(type, speed);
        }
    }

    type();
}

// ===== EFECTO RIPPLE EN BOTONES =====
function createRipple(event) {
    const button = event.currentTarget;
    const ripple = document.createElement('span');
    const diameter = Math.max(button.clientWidth, button.clientHeight);
    const radius = diameter / 2;

    ripple.style.width = ripple.style.height = `${diameter}px`;
    ripple.style.left = `${event.clientX - button.offsetLeft - radius}px`;
    ripple.style.top = `${event.clientY - button.offsetTop - radius}px`;
    ripple.classList.add('ripple-effect');

    ripple.style.cssText = `
        position: absolute;
        border-radius: 50%;
        background: rgba(255, 255, 255, 0.6);
        width: ${diameter}px;
        height: ${diameter}px;
        left: ${event.clientX - button.offsetLeft - radius}px;
        top: ${event.clientY - button.offsetTop - radius}px;
        animation: rippleAnimation 0.6s linear;
        pointer-events: none;
    `;

    const style = document.createElement('style');
    style.textContent = `
        @keyframes rippleAnimation {
            to {
                transform: scale(4);
                opacity: 0;
            }
        }
    `;
    document.head.appendChild(style);

    const rippleContainer = button.querySelector('.ripple-effect');
    if (rippleContainer) {
        rippleContainer.remove();
    }

    button.style.position = 'relative';
    button.style.overflow = 'hidden';
    button.appendChild(ripple);

    setTimeout(() => ripple.remove(), 600);
}

const buttons = document.querySelectorAll('.btn-primary, .btn-secondary, .cta-button, .github-link');
buttons.forEach(button => {
    button.addEventListener('click', createRipple);
});

// ===== ANIMACIÓN DE PROGRESO EN SCROLL =====
function updateProgressBar() {
    const winScroll = document.body.scrollTop || document.documentElement.scrollTop;
    const height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
    const scrolled = (winScroll / height) * 100;

    let progressBar = document.getElementById('progressBar');
    if (!progressBar) {
        progressBar = document.createElement('div');
        progressBar.id = 'progressBar';
        progressBar.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            height: 4px;
            background: linear-gradient(90deg, #2ECC71, #F39C12);
            z-index: 10001;
            transition: width 0.1s ease;
            box-shadow: 0 0 10px rgba(46, 204, 113, 0.8);
        `;
        document.body.appendChild(progressBar);
    }

    progressBar.style.width = scrolled + '%';
}

window.addEventListener('scroll', updateProgressBar);

// ===== EFECTO DE TILT EN FEATURE ITEMS =====
const featureItems = document.querySelectorAll('[data-tilt]');
featureItems.forEach(item => {
    item.addEventListener('mousemove', (e) => {
        if (window.innerWidth > 768) {
            const rect = item.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;

            const centerX = rect.width / 2;
            const centerY = rect.height / 2;

            const rotateX = (y - centerY) / 10;
            const rotateY = (centerX - x) / 10;

            item.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale(1.05)`;
        }
    });

    item.addEventListener('mouseleave', () => {
        item.style.transform = 'perspective(1000px) rotateX(0) rotateY(0) scale(1)';
    });
});

// ===== ANIMACIÓN DE SKILLS TAGS =====
const skillTags = document.querySelectorAll('.skill-tag');
skillTags.forEach((tag, index) => {
    tag.style.opacity = '0';
    tag.style.transform = 'translateY(20px)';

    setTimeout(() => {
        tag.style.transition = 'all 0.5s ease';
        tag.style.opacity = '1';
        tag.style.transform = 'translateY(0)';
    }, index * 100);
});

// ===== EFECTO DE GLITCH EN HOVER (PARA MEMBER CARDS) =====
const memberCards = document.querySelectorAll('.member-card');
memberCards.forEach(card => {
    const memberName = card.querySelector('.member-name');

    if (memberName) {
        const originalText = memberName.textContent;

        card.addEventListener('mouseenter', () => {
            let glitchCount = 0;
            const glitchInterval = setInterval(() => {
                if (glitchCount < 3) {
                    memberName.textContent = originalText.split('').map(char =>
                        Math.random() > 0.7 ? String.fromCharCode(33 + Math.random() * 94) : char
                    ).join('');
                    glitchCount++;
                } else {
                    memberName.textContent = originalText;
                    clearInterval(glitchInterval);
                }
            }, 50);
        });
    }
});

// ===== CONFETTI AL HACER CLIC EN CTA =====
function createConfetti(x, y) {
    const colors = ['#2ECC71', '#27AE60', '#F39C12', '#667eea', '#f093fb', '#4facfe'];

    for (let i = 0; i < 30; i++) {
        const confetti = document.createElement('div');
        const color = colors[Math.floor(Math.random() * colors.length)];
        const size = Math.random() * 8 + 4;

        confetti.style.cssText = `
            position: fixed;
            width: ${size}px;
            height: ${size}px;
            background: ${color};
            left: ${x}px;
            top: ${y}px;
            border-radius: ${Math.random() > 0.5 ? '50%' : '0'};
            pointer-events: none;
            z-index: 10000;
        `;

        document.body.appendChild(confetti);

        const angle = (Math.PI * 2 * i) / 30;
        const velocity = 3 + Math.random() * 3;
        const vx = Math.cos(angle) * velocity;
        const vy = Math.sin(angle) * velocity - 2;

        let posX = x;
        let posY = y;
        let velocityY = vy;
        let rotation = 0;

        function animate() {
            posX += vx;
            posY += velocityY;
            velocityY += 0.3; // gravedad
            rotation += 10;

            confetti.style.left = posX + 'px';
            confetti.style.top = posY + 'px';
            confetti.style.transform = `rotate(${rotation}deg)`;
            confetti.style.opacity = Math.max(0, 1 - (posY - y) / 300);

            if (posY < window.innerHeight + 50) {
                requestAnimationFrame(animate);
            } else {
                confetti.remove();
            }
        }

        animate();
    }
}

const ctaButtons = document.querySelectorAll('.cta-button');
ctaButtons.forEach(button => {
    button.addEventListener('click', (e) => {
        createConfetti(e.clientX, e.clientY);
    });
});

// ===== LAZY LOADING DE IMÁGENES =====
const imageObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            const img = entry.target;
            if (img.dataset.src) {
                img.src = img.dataset.src;
                img.classList.add('loaded');
                imageObserver.unobserve(img);
            }
        }
    });
});

document.querySelectorAll('img[data-src]').forEach(img => {
    imageObserver.observe(img);
});

// ===== ANIMACIÓN DE LAS PARTÍCULAS EN MEMBER CARDS =====
const memberCardParticles = document.querySelectorAll('.member-card .particle');
memberCardParticles.forEach(particle => {
    setInterval(() => {
        particle.style.left = Math.random() * 100 + '%';
        particle.style.top = Math.random() * 100 + '%';
    }, 3000);
});

// ===== SONIDOS AL HACER HOVER (OPCIONAL - COMENTADO POR DEFECTO) =====
/*
function playHoverSound() {
    const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBSuBzvLZiTYHGWi78OScTgwOUKzn77hcHAU7k9r0yXkpBS18ze/clEIKElyw6OyrWBYHQJnc88d3KgUthM/z1YU2Bhxqu+3mmU8LDlGs6O+6Xh0FO5PY9Ml5KwUufM/w35VDChJdruytWRcHQJnc88h3KwUthM/01YU2BRxqvO3mmU4KDlGt5++7Xh0GOpPY9Ml5KgUsfM/w35lEChFdruytWBcGQJnc88l4KwUthM/01YU2BRtqvO3mmE4KDlCt5++7XRwGOpPY9Ml5KgUsfM/x35lECQ9dre2uWhkGQJnc8sl4LAUthM/01YU2BRtqvO7mmE4JDlCt5++7XBwGOpPY9Ml5KgUsdM7x35lECQ9dre2uWhkGP5nc8sl4LAUtg8701YU2BRpqvO7mmE4JDk+t5u+7XBwFOpLX9Ml5KQUsdM7y4ZlECQ9dre2uWRkGP5nc8sl4LAUtg8701YQ2BRpqvO7mmU4JDk+t5++7WxwFOpLX9Mh4KQUsdM7y4ZlDCQ9dre6vWRkGP5nc88l4LAUtg8701oQ2BRpqvO7mmU4IDk+t5++7WxwFOpLX9Mh4KQUsdc7y4ZlDCQ5dre6vWRkGQJnc88l4LAUthM/01oQ2BRpqvO7mmU4IDk+u5u+7WxwFOpLY9Mh5KQUsdc7y4JlDCQ5dre6vWRkGQJnc88l4LAUthM/01oQ2BRpqvO7mmU4IDk+u5u+7WxwFOpLY9Mh5KQUsdc7y4JlDCQ5dre6vWRkGQJnc88l4LAUthM/01oQ2BRpqvO7mmU4IDk+u5u+7WxwFOpLY9Mh5KQUsdc7y4JlDCQ5dre6vWRkGQJnc88l4LAUthM/01oQ2BRpqvO7mmU4IDk+u5u+7WxwFOpLY9Mh5KQUsdc7y4JlDCQ5dre6vWRkGQJnc88l4LAUthM/01oQ2BRpqvO7mmU4IDk+u5u+7WxwFOpLY9Mh5KQUsdc7y4JlDCQ5dre6vWRkGQJnc88l4LAUthM/01oQ2BRpqvO7mmU4IDk+u5u+7WxwFOpLY9Mh5KQUsdc7y4JlDCQ5dre6vWRkGQJnc88l4LAUthM/01oQ2BRpqvO7mmU4IDk+u5u+7WxwFOpLY9Mh5KQUsdc7y4JlDCQ5dre6vWRkGQJnc88l4LAUthM/01oQ2BRpqvO7mmU4IDk+u5u+7WxwFOpLY9Mh5KQUsdc7y4JlDCQ5dre6vWRkGQJnc88l4LAUthM/01oQ2BRpqvO7mmU4IDk+u5u+7WxwFOpLY9Mh5KQUsdc7y4JlDCQ5dre6vWRkGQJnc88l4LAUthM/01oQ2BRpqvO7mmU4IDk+u5u+7WxwFOpLY9Mh5KQUsdc7y4JlDCQ5dre6vWRkGQJnc88l4LAUthM/01oQ2BRpqvO7mmU4IDk+u5u+7WxwFOpLY9Mh5KQUsdc7y4JlD');
    audio.volume = 0.1;
    audio.play();
}
*/

// ===== SHAKE EN ERROR O VALIDACIÓN =====
function shakeElement(element) {
    element.style.animation = 'shake 0.5s';
    setTimeout(() => {
        element.style.animation = '';
    }, 500);
}

const style = document.createElement('style');
style.textContent = `
    @keyframes shake {
        0%, 100% { transform: translateX(0); }
        10%, 30%, 50%, 70%, 90% { transform: translateX(-10px); }
        20%, 40%, 60%, 80% { transform: translateX(10px); }
    }
`;
document.head.appendChild(style);

// ===== MODO OSCURO/CLARO TOGGLE (OPCIONAL) =====
/*
let isDarkMode = true;

function toggleDarkMode() {
    isDarkMode = !isDarkMode;
    if (isDarkMode) {
        document.body.style.background = 'linear-gradient(135deg, #0f0c29 0%, #302b63 50%, #24243e 100%)';
    } else {
        document.body.style.background = 'linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%)';
    }
}
*/

// ===== EASTER EGG: CÓDIGO KONAMI =====
let konamiCode = ['ArrowUp', 'ArrowUp', 'ArrowDown', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'ArrowLeft', 'ArrowRight', 'b', 'a'];
let konamiIndex = 0;

document.addEventListener('keydown', (e) => {
    if (e.key === konamiCode[konamiIndex]) {
        konamiIndex++;
        if (konamiIndex === konamiCode.length) {
            activateEasterEgg();
            konamiIndex = 0;
        }
    } else {
        konamiIndex = 0;
    }
});

function activateEasterEgg() {
    // Crear lluvia de emojis
    const emojis = ['🥗', '🍎', '🥦', '🥕', '🥑', '🍇', '🤖', '💚', '⭐', '✨'];

    for (let i = 0; i < 50; i++) {
        setTimeout(() => {
            const emoji = document.createElement('div');
            emoji.textContent = emojis[Math.floor(Math.random() * emojis.length)];
            emoji.style.cssText = `
                position: fixed;
                font-size: 3rem;
                left: ${Math.random() * 100}vw;
                top: -50px;
                z-index: 10000;
                pointer-events: none;
                animation: fall 3s linear;
            `;

            const fallAnimation = document.createElement('style');
            fallAnimation.textContent = `
                @keyframes fall {
                    to {
                        transform: translateY(${window.innerHeight + 100}px) rotate(360deg);
                    }
                }
            `;
            document.head.appendChild(fallAnimation);

            document.body.appendChild(emoji);

            setTimeout(() => emoji.remove(), 3000);
        }, i * 100);
    }

    // Mostrar mensaje
    const message = document.createElement('div');
    message.textContent = '🎉 ¡Código Konami Activado! 🎉';
    message.style.cssText = `
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: linear-gradient(135deg, #2ECC71, #27AE60);
        color: white;
        padding: 2rem 4rem;
        border-radius: 20px;
        font-size: 2rem;
        font-weight: bold;
        z-index: 10001;
        box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
        animation: popIn 0.5s cubic-bezier(0.68, -0.55, 0.265, 1.55);
    `;

    const popAnimation = document.createElement('style');
    popAnimation.textContent = `
        @keyframes popIn {
            0% { transform: translate(-50%, -50%) scale(0); }
            100% { transform: translate(-50%, -50%) scale(1); }
        }
    `;
    document.head.appendChild(popAnimation);

    document.body.appendChild(message);

    setTimeout(() => {
        message.style.animation = 'popIn 0.5s cubic-bezier(0.68, -0.55, 0.265, 1.55) reverse';
        setTimeout(() => message.remove(), 500);
    }, 2000);
}

// ===== LOG DE BIENVENIDA EN CONSOLA =====
console.log('%c¡Bienvenido a NutriBot! 🥗', 'color: #2ECC71; font-size: 30px; font-weight: bold; text-shadow: 2px 2px 4px rgba(0,0,0,0.3);');
console.log('%cProyecto de código abierto 💚', 'color: #27AE60; font-size: 16px; font-weight: bold;');
console.log('%cGitHub: https://github.com/holamundoxdfs/Proyecto', 'color: #F39C12; font-size: 14px;');
console.log('%c¿Sabías que? Puedes usar el código Konami (↑↑↓↓←→←→BA) para activar un easter egg 😉', 'color: #667eea; font-size: 12px; font-style: italic;');

// ===== PERFORMANCE: DEBOUNCE PARA EVENTOS DE SCROLL =====
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// ===== INICIALIZACIÓN FINAL =====
document.addEventListener('DOMContentLoaded', () => {
    console.log('%c✅ NutriBot cargado correctamente', 'color: #2ECC71; font-size: 14px; font-weight: bold;');

    // Animación de entrada para el body
    document.body.style.opacity = '0';
    setTimeout(() => {
        document.body.style.transition = 'opacity 0.5s ease';
        document.body.style.opacity = '1';
    }, 100);
});