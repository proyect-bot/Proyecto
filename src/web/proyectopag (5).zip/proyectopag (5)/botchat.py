def chatbot():
    print("👋 ¡Hola! Soy tu asistente de alimentación saludable.")
    print("¿Listo para aprender a comer mejor?\n")

    print("1. Sí, empecemos")
    print("2. No, gracias")
    opcion = input("Elige una opción: ")

    if opcion == "1":
        print("\nExcelente. ¿Qué comida quieres planear?")
        print("1. Desayuno")
        print("2. Almuerzo")
        print("3. Cena")
        comida = input("Elige una opción: ")

        if comida == "1":
            print("\nPara un desayuno saludable puedes elegir:")
            print("1. Avena con frutas")
            print("2. Pan integral con huevo")
            print("3. Yogur con granola")
            eleccion = input("¿Cuál prefieres? ")
            print("\nBuena elección. Recuerda acompañarlo con agua o un jugo natural.")

        elif comida == "2":
            print("\nPara el almuerzo saludable puedes elegir:")
            print("1. Pollo a la plancha con ensalada")
            print("2. Arroz integral con pescado y verduras")
            print("3. Lentejas con aguacate y plátano asado")
            eleccion = input("¿Cuál prefieres? ")
            print("\nExcelente. Es importante incluir vegetales y evitar bebidas azucaradas.")

        elif comida == "3":
            print("\nPara la cena puedes elegir:")
            print("1. Ensalada con pollo o atún")
            print("2. Sopa de verduras")
            print("3. Arepa integral con queso bajo en grasa")
            eleccion = input("¿Cuál prefieres? ")
            print("\nPerfecto. Una cena ligera ayuda a dormir mejor.")

        else:
            print("\nOpción no válida. Intenta de nuevo.")

        print("\n🌟 ¡Muy bien! Has tomado decisiones saludables. Recuerda que una buena alimentación te da energía y bienestar. 🌟")

    else:
        print("\nEstá bien. ¡Nos vemos luego! Cuida tu salud 💪")

chatbot()
